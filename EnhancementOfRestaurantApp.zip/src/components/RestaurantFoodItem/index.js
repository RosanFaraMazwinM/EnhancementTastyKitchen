import './index.css'
import {Component} from 'react'
import {BsPlusSquare, BsDashSquare} from 'react-icons/bs'
import {ImStarFull} from 'react-icons/im'
import {FaRupeeSign} from 'react-icons/fa'
import CartContext from '../../context/CartContext'

class RestaurantFoodItem extends Component {
  state = {selectedQuantity: 0}

  render() {
    const {foodItemDetails} = this.props
    const {id, imageUrl, name, cost, rating} = foodItemDetails
    const {selectedQuantity} = this.state

    return (
      <CartContext.Consumer>
        {value => {
          const {cartList, addCartItem, incrementCartItemQuantity, decrementCartItemQuantity} = value
          const cartItem = cartList.find(item => item.id === id)
          const quantity = cartItem ? cartItem.quantity : selectedQuantity
          const isAdded = Boolean(cartItem)

          const increase = () => {
            if (isAdded) {
              incrementCartItemQuantity(id)
            } else {
              this.setState(prev => ({selectedQuantity: prev.selectedQuantity + 1}))
            }
          }
          const decrease = () => {
            if (isAdded) {
              decrementCartItemQuantity(id)
            } else if (selectedQuantity > 0) {
              this.setState(prev => ({selectedQuantity: prev.selectedQuantity - 1}))
            }
          }
          const addToCart = () => {
            addCartItem({...foodItemDetails, quantity: selectedQuantity})
            this.setState({selectedQuantity: 0})
          }

          return (
            <li data-testid="foodItem" className="food-item">
              <img src={imageUrl} alt={name} className="food-item-image" />
              <div>
                <h1 className="food-name">{name}</h1>
                <div className="food-cost-container"><FaRupeeSign className="food-rupees-icon" /><p className="food-cost">{cost}</p></div>
                <div className="food-rating-container"><ImStarFull className="star-icon" /><p className="food-rating">{rating}</p></div>
                <div className="food-quantity-container">
                  <button data-testid="decrement-count" onClick={decrease} type="button" className="food-quantity-controller-button"><BsDashSquare className="food-quantity-controller-icon" /></button>
                  <p data-testid="active-count" className="food-quantity">{quantity}</p>
                  <button data-testid="increment-count" onClick={increase} type="button" className="food-quantity-controller-button"><BsPlusSquare className="food-quantity-controller-icon" /></button>
                </div>
                {!isAdded && selectedQuantity > 0 && (
                  <button onClick={addToCart} className="add-food-button" type="button">ADD TO CART</button>
                )}
              </div>
            </li>
          )
        }}
      </CartContext.Consumer>
    )
  }
}

export default RestaurantFoodItem
