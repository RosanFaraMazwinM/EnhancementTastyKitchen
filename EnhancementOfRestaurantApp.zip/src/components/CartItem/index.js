import {BsPlusSquare, BsDashSquare} from 'react-icons/bs'
import CartContext from '../../context/CartContext'
import './index.css'

const CartItem = props => {
  const {eachItem} = props
  const {id, imageUrl, name, cost, quantity} = eachItem

  return (
    <CartContext.Consumer>
      {value => {
        const {incrementCartItemQuantity, decrementCartItemQuantity, removeCartItem} = value
        return (
          <li data-testid="cartItem" className="mobile-list-cart-item">
            <img className="mobile-cart-item-image" src={imageUrl} alt={name} />
            <div>
              <h1 className="cart-Item-name">{name}</h1>
              <div className="cartItem-quantity-container">
                <button data-testid="decrement-quantity" type="button" className="decrement-button" onClick={() => decrementCartItemQuantity(id)}><BsDashSquare /></button>
                <span data-testid="item-quantity" className="cart-item-quantity">{quantity}</span>
                <button data-testid="increment-quantity" type="button" className="increment-button" onClick={() => incrementCartItemQuantity(id)}><BsPlusSquare /></button>
              </div>
              <p data-testid="total-price" className="cart-item-cost">₹ {cost * quantity}</p>
              <button type="button" className="remove-cart-item-button" onClick={() => removeCartItem(id)}>Remove</button>
            </div>
          </li>
        )
      }}
    </CartContext.Consumer>
  )
}

export default CartItem
