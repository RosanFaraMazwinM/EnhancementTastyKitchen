import {Component} from 'react'
import {Link, withRouter} from 'react-router-dom'
import Cookies from 'js-cookie'
import CartContext from '../../context/CartContext'
import './index.css'

class HeaderPage extends Component {
  static contextType = CartContext

  state = {isMobileMenuClicked: false}

  onClickLogout = () => {
    Cookies.remove('jwt_token')
    this.props.history.replace('/login')
  }

  onClickMenuBar = () => this.setState(prev => ({isMobileMenuClicked: !prev.isMobileMenuClicked}))
  onCloseClicked = () => this.setState({isMobileMenuClicked: false})

  render() {
    const {isMobileMenuClicked} = this.state
    const {location} = this.props
    const {cartList} = this.context
    const cartCount = cartList.length
    const isHomeActive = location.pathname === '/'
    const isCartActive = location.pathname === '/cart'

    return (
      <nav className="nav-header">
        <div className="nav-content">
          <div className="nav-bar-mobile-logo-container">
            <Link to="/" className="nav-link">
              <div className="header-logo-container">
                <img className="website-logo" src="https://i.postimg.cc/JznRzjGZ/Logo.png" alt="website logo" />
                <p className="logo-name">Tasty Kitchens</p>
              </div>
            </Link>
            <button type="button" className="nav-mobile-btn" onClick={this.onClickMenuBar}>
              <img src="https://i.postimg.cc/YSZwxPWC/menu.png" alt="nav menu" className="nav-bar-image" />
            </button>
          </div>
          <div className="nav-bar-large-container">
            <Link to="/" className="nav-link">
              <div className="header-logo-container">
                <img className="website-logo" src="https://i.postimg.cc/JznRzjGZ/Logo.png" alt="website logo" />
                <p className="logo-name">Tasty Kitchens</p>
              </div>
            </Link>
            <ul className="nav-menu">
              <li className="nav-menu-item">
                <Link to="/" className={`nav-link ${isHomeActive ? 'active-tab active' : 'active-tab'}`}>Home</Link>
              </li>
              <li className="nav-menu-item">
                <Link to="/cart" className={`nav-link ${isCartActive ? 'active-tab active' : 'active-tab'}`}>
                  <button type="button" data-testid="cart" className="header-cart-button">
                    Cart {cartCount > 0 && <span className="cart-count-badge">{cartCount}</span>}
                  </button>
                </Link>
              </li>
            </ul>
            <button type="button" className="logout-desktop-btn" onClick={this.onClickLogout}>Logout</button>
          </div>
        </div>
        {isMobileMenuClicked && (
          <div className="nav-mobile-only-menu">
            <div className="nav-menu-mobile">
              <div className="nav-menu-container">
                <ul className="nav-menu-list-mobile">
                  <li className="nav-menu-item-mobile"><Link to="/" className="nav-link">Home</Link></li>
                  <li className="nav-menu-item-mobile">
                    <Link to="/cart" className="nav-link">
                      <button type="button" data-testid="cart" className="header-cart-button">Cart {cartCount > 0 && <span className="cart-count-badge">{cartCount}</span>}</button>
                    </Link>
                  </li>
                </ul>
                <button type="button" className="logout-desktop-btn-mobile" onClick={this.onClickLogout}>Logout</button>
              </div>
              <img src="https://i.postimg.cc/768Whrzf/Solid.png" alt="nav close" className="nav-bar-image" onClick={this.onCloseClicked} />
            </div>
          </div>
        )}
      </nav>
    )
  }
}

export default withRouter(HeaderPage)
