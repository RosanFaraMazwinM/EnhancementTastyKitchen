import {Component} from 'react'
import {Link} from 'react-router-dom'
import CartContext from '../../context/CartContext'
import CartItem from '../CartItem'
import HeaderPage from '../HeaderPage'
import Footer from '../Footer'
import './index.css'

class Cart extends Component {
  render() {
    return (
      <CartContext.Consumer>
        {value => {
          const {cartList, removeAllCartItems} = value
          const totalAmount = cartList.reduce(
            (total, item) => total + item.cost * item.quantity,
            0,
          )
          return (
            <>
              <HeaderPage />
              {cartList.length > 0 ? (
                <div className="cart-container">
                  <div className="cart-responsive-container">
                    <div className="cart-title-row">
                      <h1 className="cart-page-heading">My Cart</h1>
                      <button type="button" className="remove-all-button" onClick={removeAllCartItems}>Remove All</button>
                    </div>
                    <ul className="cart-list-container">
                      {cartList.map(item => <CartItem eachItem={item} key={item.id} />)}
                    </ul>
                    <hr className="cart-line" />
                    <div className="total-cart-amount-container">
                      <h1 className="total-order-text">Order Total:</h1>
                      <p data-testid="total-price" className="total-order-amount">₹{totalAmount}</p>
                    </div>
                    <div className="place-order-button-container">
                      <button type="button" className="cart-place-order-button" onClick={removeAllCartItems}>Place Order</button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="empty-cart-container">
                  <div className="empty-cart-responsive-container">
                    <img className="empty-cart-image" src="https://res.cloudinary.com/nsp/image/upload/v1636379708/tastyKitchens/empty_cart_1_1x_o1nekx.png" alt="empty cart" />
                    <h1 className="empty-cart-heading">No Order Yet!</h1>
                    <p className="empty-cart-para">Your cart is empty. Add something from the menu.</p>
                    <Link to="/"><button className="empty-cart-button" type="button">Order Now</button></Link>
                  </div>
                </div>
              )}
              <Footer />
            </>
          )
        }}
      </CartContext.Consumer>
    )
  }
}

export default Cart
