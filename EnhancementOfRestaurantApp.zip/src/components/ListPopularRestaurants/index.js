import {RiArrowDropLeftLine, RiArrowDropRightLine} from 'react-icons/ri'

import {Component} from 'react'
import Cookies from 'js-cookie'
import Loader from 'react-loader-spinner'
import RestaurantHeader from '../RestaurantHeader'
import RestaurantCard from '../RestaurantCard'
import './index.css'

const sortByOptions = [
  {
    id: 1,
    displayText: 'Highest',
    value: 'Highest',
  },
  {
    id: 2,
    displayText: 'Lowest',
    value: 'Lowest',
  },
]

class PopularRestaurants extends Component {
  state = {
    restaurantList: [],
    isLoading: true,
    selectedSortByValue: sortByOptions[1].value,
    activePage: 1,
    searchInput: '',
  }

  componentDidMount() {
    this.getRestaurantsData()
  }

  getRestaurantsData = async () => {
    this.setState({
      isLoading: true,
    })
    const jwtToken = Cookies.get('jwt_token')
    const {selectedSortByValue, activePage} = this.state
    const limit = 9
    const offset = (activePage - 1) * limit
    const url = `https://apis.ccbp.in/restaurants-list?offset=${offset}&limit=${limit}&sort_by_rating=${selectedSortByValue}`

    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: 'GET',
    }
    const response = await fetch(url, options)
    if (response.ok) {
      const fetchedData = await response.json()
      const updatedData = fetchedData.restaurants.map(restaurant => ({
        costForTwo: restaurant.cost_for_two,
        cuisine: restaurant.cuisine,
        groupByTime: restaurant.group_by_time,
        hasOnlineDelivery: restaurant.has_online_delivery,
        hasTableBooking: restaurant.has_table_booking,
        id: restaurant.id,
        imageUrl: restaurant.image_url,
        isDeliveringNow: restaurant.is_delivering_now,
        location: restaurant.location,
        menuType: restaurant.menu_type,
        name: restaurant.name,
        opensAt: restaurant.opens_at,
        userRating: restaurant.user_rating,
        totalReviews: restaurant.user_rating.total_reviews,
      }))
      console.log(fetchedData)
      this.setState({
        restaurantList: updatedData,
        isLoading: false,
      })
      console.log(updatedData)
    }
  }

  updateSelectedSortByValue = selectedSortByValue => {
    this.setState({selectedSortByValue}, this.getRestaurantsData)
  }

  onClickLeftArrow = () => {
    const {activePage} = this.state
    if (activePage > 1) {
      this.setState(
        prevState => ({
          activePage: prevState.activePage - 1,
        }),
        this.getRestaurantsData,
      )
    }
  }

  onClickRightArrow = () => {
    const {activePage} = this.state
    if (activePage < 4) {
      this.setState(
        prevState => ({
          activePage: prevState.activePage + 1,
        }),
        this.getRestaurantsData,
      )
    }
  }

  onChangeSearchInput = input => {
    this.setState({searchInput: input})
  }

  renderRestaurantsList = () => {
    const {
      restaurantList,
      selectedSortByValue,
      activePage,
      searchInput,
    } = this.state
    const updatedList = restaurantList.filter(each =>
      each.name.toLowerCase().includes(searchInput.toLowerCase()),
    )
    return (
      <div className="popular-restaurants">
        <RestaurantHeader
          selectedSortByValue={selectedSortByValue}
          sortByOptions={sortByOptions}
          updateSelectedSortByValue={this.updateSelectedSortByValue}
          onChangeSearchInput={this.onChangeSearchInput}
        />
        <hr className="hr-line" />
        {updatedList.length === 0 ? (
          <div className="no-restaurants-container">
            <h1 className="restaurant-failure-heading-text">
              No Restaurants Found
            </h1>
          </div>
        ) : (
          <>
            <ul className="restaurants-list">
              {updatedList.map(restaurant => (
                <RestaurantCard
                  restaurantData={restaurant}
                  key={restaurant.id}
                />
              ))}
            </ul>
            <div className="restaurants-pagination">
              <button
                data-testid="pagination-left-button"
                className="pagination-button"
                type="button"
                onClick={this.onClickLeftArrow}
              >
                <RiArrowDropLeftLine
                  id="pagination-left-button"
                  className="pagination-arrow-icon"
                />
              </button>
              <p
                data-testid="active-page-number"
                className="restaurants-page-numbers"
              >
                {activePage}
              </p>
              <button
                data-testid="pagination-right-button"
                className="pagination-button"
                type="button"
                onClick={this.onClickRightArrow}
              >
                <RiArrowDropRightLine
                  id="pagination-right-button"
                  className="pagination-arrow-icon"
                />
              </button>
            </div>
          </>
        )}
      </div>
    )
  }

  renderLoadingView = () => (
    <div data-testid="restaurants-list-loader" className="restaurants-loader">
      <Loader type="TailSpin" color="#F7931E" height={50} width={50} />
    </div>
  )

  render() {
    const {isLoading} = this.state
    return isLoading ? this.renderLoadingView() : this.renderRestaurantsList()
  }
}

export default PopularRestaurants
