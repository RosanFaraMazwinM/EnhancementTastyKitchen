import {Component} from 'react'
import {Route, Switch, Redirect} from 'react-router-dom'
import LoginPage from './components/LoginPage'
import HomePage from './components/HomePage'
import RestaurantDetails from './components/RestaurantDetails'
import ProtectedRoute from './components/ProtectedRoute'
import CartContext from './context/CartContext'
import NotFound from './components/NotFound'
import Cart from './components/Cart'
import './App.css'

const getCartListFromLocalStorage = () => {
  try {
    const data = JSON.parse(localStorage.getItem('cartData'))
    return Array.isArray(data) ? data : []
  } catch (error) {
    return []
  }
}

class App extends Component {
  state = {cartList: getCartListFromLocalStorage()}

  componentDidUpdate() {
    localStorage.setItem('cartData', JSON.stringify(this.state.cartList))
  }

  addCartItem = item => {
    this.setState(prevState => {
      const exists = prevState.cartList.some(each => each.id === item.id)
      if (exists) {
        return {
          cartList: prevState.cartList.map(each =>
            each.id === item.id
              ? {...each, quantity: each.quantity + (item.quantity || 1)}
              : each,
          ),
        }
      }
      return {cartList: [...prevState.cartList, {...item, quantity: item.quantity || 1}]}
    })
  }

  removeCartItem = id => {
    this.setState(prev => ({
      cartList: prev.cartList.filter(each => each.id !== id),
    }))
  }

  incrementCartItemQuantity = id => {
    this.setState(prev => ({
      cartList: prev.cartList.map(each =>
        each.id === id ? {...each, quantity: each.quantity + 1} : each,
      ),
    }))
  }

  decrementCartItemQuantity = id => {
    this.setState(prev => ({
      cartList: prev.cartList
        .map(each =>
          each.id === id ? {...each, quantity: each.quantity - 1} : each,
        )
        .filter(each => each.quantity > 0),
    }))
  }

  removeAllCartItems = () => this.setState({cartList: []})

  render() {
    const {cartList} = this.state
    const contextValue = {
      cartList,
      removeAllCartItems: this.removeAllCartItems,
      addCartItem: this.addCartItem,
      removeCartItem: this.removeCartItem,
      incrementCartItemQuantity: this.incrementCartItemQuantity,
      decrementCartItemQuantity: this.decrementCartItemQuantity,
    }
    return (
      <CartContext.Provider value={contextValue}>
        <Switch>
          <Route exact path="/login" component={LoginPage} />
          <ProtectedRoute exact path="/" component={HomePage} />
          <ProtectedRoute exact path="/restaurant/:id" component={RestaurantDetails} />
          <ProtectedRoute exact path="/cart" component={Cart} />
          <Route path="/not-found" component={NotFound} />
          <Redirect to="/not-found" />
        </Switch>
      </CartContext.Provider>
    )
  }
}

export default App
